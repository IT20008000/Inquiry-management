package com;
import java.sql.*;
public class Inquiry {
	//A common method to connect to the DB
		private Connection connect()
		 {
		 Connection con = null;
		 try
		 {
		 Class.forName("com.mysql.jdbc.Driver");

		
		 con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/customer", "root", "");
		 System.out.print("connected");
		 }
		 catch (Exception e)
		 {e.printStackTrace();}
		 return con;
		 }
		
		//Insert Query
		public String insertinquirymanagement(String inquiry_id, String account_no,String address,String phone, String subject, String message)
		 {
		 String output = "";
		 try
		 {
		 Connection con = connect();
		 if (con == null)
		 {
			 return "Error while connecting to the database for inserting."; 
		 }
		 
		 // create a prepared statement
		 String query = " insert into Inquiry (`inq_id`,`account_no`,`address`,`phone`, `subject`, `message`)" + " values (?, ?, ?, ?, ?, ?, ?, ?)";
		 PreparedStatement preparedStmt = con.prepareStatement(query);
		 // binding values
		 preparedStmt.setInt(1, 0);
		 preparedStmt.setString(2, inquiry_id);
		 preparedStmt.setString(3, account_no);
		 preparedStmt.setString(4, address);
		 preparedStmt.setString(5, phone);
		 preparedStmt.setString(6, subject);
		 preparedStmt.setString(7, message);

		
		// execute the statement
		
		 preparedStmt.execute();
		 con.close();
		 
		 String newInquiry = readInquiry();
		 
		 
		 output = "{\"status\":\"success\", \"data\": \"" + newInquiry + "\"}";
		 output = "Inserted Inquiry Details Successfully";
		 }
		 catch (Exception e)
		 {
		 output = "{\"status\":\"error\", \"data\":\"Error while inserting the item.\"}";
		 output = "Error while inserting the Inquiry Details.";
		 System.err.println(e.getMessage());
		 }
		 return output;
		 }
		
//Get Query
public String readInquiry()
	{
		 String output = "";
	try
	{
	Connection con = connect();
	if (con == null)
	{
		return "Error while connecting to the database for reading."; 
	}
		 
 // Prepare the html table to be displayed
		 output = "<table border='1'><tr><th>Inquiry Id</th>" +
		 "<th>Account no</th>" +
		 "<th>address</th>"+
		 "<th>phone</th>"+
		 "<th>subject</th>"+
		 "<th>message</th>"+


		 String query = "select * from inquiry";
		 Statement stmt = con.createStatement();
		 ResultSet rs = stmt.executeQuery(query);
		 // iterate through the rows in the result set
		 while (rs.next())
		 {
		 String acc_no = Integer.toString(rs.getInt("Inquiry Id"));
		 String cust_name = rs.getString("Account no");
		 String address = rs.getString("address");
		 String nic = rs.getString("phone");
		 String district = rs.getString("subject");
		 String mobile = rs.getString("message");

		
		// Add a row into the html table
		 
		 //output += "<tr><td><input id='hidAccIDUpdate' name='hidAccIDUpdate' type='hidden' value='" + acc_no
					//+ "'>" + cust_name + "</td>";
		 output += "<tr><td>" + inquiry id + "</td>";
		 output += "<td>" + account no + "</td>";
		 output += "<td>" + address + "</td>";
		 output += "<td>" + phone + "</td>";
		 output += "<td>" + subject + "</td>";
		 output += "<td>" + message + "</td>";

		 
		// buttons
		output += "<td><input id='btnUpdate' type='button' value='Update' class='btnUpdate btn btn-secondary' data-accid='" + inq_id + "'></td>"
				//+ "<td><form method='post' action='items.jsp'>"
				+ "<td><input id='btnRemove' type='button' value='Remove' class='btnRemove btn btn-danger' data-accid='" + inq_id + "'></td></tr>";
		 }
				 con.close();
				// Complete the html table
				 output += "</table>";
				 } 
		 catch (Exception e)
		 {
		 output = "Error while reading the Datas.";
		 System.err.println(e.getMessage());
		 }
		 return output;
		 }
		
//Update Query

public String updateinquirymanagement(String inquiry id , String account no, String address, String phone, String subject, String message )
	{
		 String output = "";
	try
	{
		Connection con = connect();
		 if (con == null){
			 return "Error while connecting to the database for updating."; 
		 }
		 // create a prepared statement
		 String query = "UPDATE inquiry SET inquiry_id=?, account no=?, =?, address=?, phone=?, subject=?,message=?;
		 
		 PreparedStatement preparedStmt = con.prepareStatement(query);
		 // binding values
		 
		//preparedStmt.setString(1, 0 );
		 preparedStmt.setString(1, inquiry_id);
		 preparedStmt.setString(2, account no);
		 preparedStmt.setString(3, address);
		 preparedStmt.setString(4, phone);
		 preparedStmt.setString(5, subject);
		 preparedStmt.setString(6, message);

		 
		 // execute the statement
		 preparedStmt.execute();
		 con.close();
		 
		 String newInquiry = readInquiry();
		 output = "{\"status\":\"success\", \"data\": \"" + newInquiry + "\"}";
		 output = "Updated Inquiry Details Successfully";
		 }
		 catch (Exception e)
		 {
		 output = "{\"status\":\"error\", \"data\":\"Error while updating the Inquiry Details..\"}";
		 output = "Error while updating the Inquiry Details.";
		 System.out.println(e.getMessage());
		 }
		 return output;
		 }


		
		//Delete Query
		public String deleteInquirymanagement(String inquiry_id)
		 {
		 String output = "";
		 try
		 {
		 Connection con = connect();
		 if (con == null)
		 {return "Error while connecting to the database for deleting."; }
		 // create a prepared statement
		 String query = "delete from Inquiry where acc_no=?";
		 PreparedStatement preparedStmt = con.prepareStatement(query);
		 // binding values
		 preparedStmt.setInt(1, Integer.parseInt(inquiry_id));
		 // execute the statement
		 preparedStmt.execute();
		 con.close();
		 
		 String newInquiry = readInquiry();
		 output = "{\"status\":\"success\", \"data\": \"" + newInquiry + "\"}";
		 output = "Deleted Inquiry Details Successfully";
		 }
		 catch (Exception e)
		 {
			 output = "{\"status\":\"error\", \"data\":\"Error while deleting the item.\"}";
		 output = "Error while deleting the Inquiry Details.";
		 System.out.println(e.getMessage());
		 }
		 return output;
		 }

		} 

